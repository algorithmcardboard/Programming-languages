%% find all followers of @anirudhan
follows(F, @anirudhan).

%% find all tweets of @anirudhan
tweet(@anirudhan,I,M)

%% find all tweets of @anirudhan
